DROP TABLE employee;
