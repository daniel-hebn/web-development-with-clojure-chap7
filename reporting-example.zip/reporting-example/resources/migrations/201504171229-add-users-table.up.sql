CREATE TABLE employee
(name VARCHAR(50),
 occupation VARCHAR(50),
 place VARCHAR(50),
 country VARCHAR(50));
