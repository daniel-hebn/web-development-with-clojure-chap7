-- :name read-employees :? :*
-- reads the list of employees
select * from employee
